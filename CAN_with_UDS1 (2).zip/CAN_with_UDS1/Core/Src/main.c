
#include "main.h"
#include <stdbool.h>

 uint8_t tdata[10];
 uint8_t rdata[10];
 uint32_t txmailbox;

 CAN_HandleTypeDef hcan;

#define S3_CNT_TIMEOUT      5000

#define UDS_DEFAULT_SESSION             ( 0x01U )
#define UDS_PRGRAMMING_SESSION          ( 0x02U )
#define UDS_EXTENDED_SESSION            ( 0x03U )

 uint8_t udsCurSession_u8 = UDS_DEFAULT_SESSION;
 bool s3_server_active_flg;
 uint32_t u32_S3_server_cnt;
 static uint8_t seq_cnt=0; // sequence counter
 CAN_TxHeaderTypeDef tx_head;
 CAN_FilterTypeDef fi_head;
 CAN_RxHeaderTypeDef rx_head;

 /* Security Access Mode */
 typedef enum
 {
    SECURITY_UNLOCK,
    SECURITY_LOCK

 }SecurityAccessState_t;


void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CAN_Init(void);

void can_tx(void);
void can_rx(void);
void filer_config(void);
void incorrectmsglength(void);
void requestoutofrange(void);
void udsreadcall(void);
void  sendspeed(void);
void  sendtemp(void);

static SecurityAccessState_t securityAccessState_en = SECURITY_LOCK;


int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_CAN_Init();


  HAL_CAN_WakeUp(&hcan);
  filer_config();
  HAL_CAN_Start(&hcan);


  while (1)
  {
			  can_rx();

  }

}


void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}



static void MX_CAN_Init(void)
{


  hcan.Instance = CAN;
  hcan.Init.Prescaler = 16;
  hcan.Init.Mode = CAN_MODE_NORMAL;
  hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1 = CAN_BS1_2TQ;
  hcan.Init.TimeSeg2 = CAN_BS2_1TQ;
  hcan.Init.TimeTriggeredMode = DISABLE;
  hcan.Init.AutoBusOff = DISABLE;
  hcan.Init.AutoWakeUp = DISABLE;
  hcan.Init.AutoRetransmission = DISABLE;
  hcan.Init.ReceiveFifoLocked = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK)
  {
    Error_Handler();
  }

 // hcan.Instance->MCR &= (~CAN_MCR_SLEEP);   //     hcan.Instance->MCR   = hcan.Instance->MCR     &     (~CAN_MCR_SLEEP)



}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA5 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

void  sendspeed(void)
{
	tx_head.DLC=5;
	tx_head.IDE=CAN_ID_STD;
	tx_head.StdId=0x100;
	tx_head.RTR=CAN_RTR_DATA;

	tdata[0]= 0x62;
	tdata[1]= 0xFF;
	tdata[2]= 0x01;
	tdata[3]= 0x10;
	tdata[4]= 0x11;


	if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
	{
		Error_Handler();
	}

	while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
}

void  sendtemp(void)
{
	tx_head.DLC=6;
	tx_head.IDE=CAN_ID_STD;
	tx_head.StdId=0x100;
	tx_head.RTR=CAN_RTR_DATA;

	tdata[0]= 0x62;
		tdata[1]= 0xFF;
		tdata[2]= 0x02;
		tdata[3]= 0x20;
		tdata[4]= 0x21;
		tdata[5]= 0x22;


	if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
	{
		Error_Handler();
	}

	while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
}


void incorrectmsglength(void)
{
	    tx_head.DLC=3;
		tx_head.IDE=CAN_ID_STD;
		tx_head.StdId=0x100;
		tx_head.RTR=CAN_RTR_DATA;

		tdata[0]= 0x7F;
		tdata[1]= 0x22;
		tdata[2]= 0x13;

		if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
		{
			Error_Handler();
		}

		while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
}

void requestoutofrange(void)
{

			tx_head.DLC=3;
			tx_head.IDE=CAN_ID_STD;
			tx_head.StdId=0x100;
			tx_head.RTR=CAN_RTR_DATA;

			tdata[0]= 0x7F;
			tdata[1]= 0x22;
			tdata[2]= 0x31;

			if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
			{
				Error_Handler();
			}

			while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

}

void filer_config(void)
{

	fi_head.FilterActivation= CAN_FILTER_ENABLE;
	fi_head.FilterBank= 0;
	fi_head.FilterFIFOAssignment=CAN_FILTER_FIFO0;
	fi_head.FilterIdHigh= 0x300<<5;
	fi_head.FilterIdLow= 0x000;
	fi_head.FilterMode=CAN_FILTERMODE_IDLIST;
	fi_head.FilterScale= CAN_FILTERSCALE_32BIT;
	HAL_CAN_ConfigFilter( &hcan,&fi_head );
}





void can_rx(void)
{
	while(! HAL_CAN_GetRxFifoFillLevel ( &hcan, CAN_RX_FIFO0)) ;

	if( HAL_CAN_GetRxMessage(&hcan, CAN_RX_FIFO0, &rx_head, rdata) != HAL_OK)
	{
		Error_Handler();
	}

	//sendspeed();

	if ( rdata[0]==0x22) // Read data by identifier
		{
		if (  rx_head.DLC == 3)
				{
					if (rdata[2] > 0x02 )
						{   //requestoutofrange();

									tx_head.DLC=3;
									tx_head.IDE=CAN_ID_STD;
									tx_head.StdId=0x140;
									tx_head.RTR=CAN_RTR_DATA;

									tdata[0]= 0x7F;
									tdata[1]= 0x22;
									tdata[2]= 0x31;

									if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
									{
										Error_Handler();
									}

									while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

						}

					//if ( (rdata[1]==0xff)  &&  (rdata[2]==0x1) )
					if (rdata[2] == 0x01 )
					   {
						//sendspeed();

							tx_head.DLC=5;
							tx_head.IDE=CAN_ID_STD;
							tx_head.StdId=0x200;
							tx_head.RTR=CAN_RTR_DATA;

							tdata[0]= 0x62;
							tdata[1]= 0xFF;
							tdata[2]= 0x01;
							tdata[3]= 0x10;
							tdata[4]= 0x11;


							if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
							{
								Error_Handler();
							}

							while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

					   }

					//if ( (rdata[1]==0xFF)  &&  (rdata[2]==0x2) )
					if (rdata[2] == 0x02 )
						  {
								//sendtemp();
							tx_head.DLC=6;
							tx_head.IDE=CAN_ID_STD;
							tx_head.StdId=0x100;
							tx_head.RTR=CAN_RTR_DATA;

								tdata[0]= 0x62;
								tdata[1]= 0xFF;
								tdata[2]= 0x02;
								tdata[3]= 0x20;
								tdata[4]= 0x21;
								tdata[5]= 0x22;


							if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
							{
								Error_Handler();
							}

							while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

						  }

				}

				else
				{
					//incorrectmsglength();
					tx_head.DLC=3;
							tx_head.IDE=CAN_ID_STD;
							tx_head.StdId=0x120;
							tx_head.RTR=CAN_RTR_DATA;

							tdata[0]= 0x7F;
							tdata[1]= 0x22;
							tdata[2]= 0x13;

							if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
							{
								Error_Handler();
							}

							while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
				}

		}
	else if ( rdata[0]==0x24) // Read scaling data by identifier
			{
			if (  rx_head.DLC == 3)
					{
						if ((rdata[1] != 0xF0) || (rdata[2] != 0x9F) )
							{
							          //requestoutofrange();

										tx_head.DLC=3;
										tx_head.IDE=CAN_ID_STD;
										tx_head.StdId=0x140;
										tx_head.RTR=CAN_RTR_DATA;

										tdata[0]= 0x7F;
										tdata[1]= 0x24;
										tdata[2]= 0x31;

										if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
										{
											Error_Handler();
										}

										while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

							}

						if ((rdata[1] == 0xF0) && (rdata[2] == 0x9F) )
							{
							         //Pos Resp

											tx_head.DLC=5;
											tx_head.IDE=CAN_ID_STD;
											tx_head.StdId=0x140;
											tx_head.RTR=CAN_RTR_DATA;

											tdata[0]= 0x64;
											tdata[1]= rdata[1];
											tdata[2]= rdata[2];
											tdata[3]= 0x60;
											tdata[4]= 0x5F;


											if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
											{
												Error_Handler();
											}

											while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

							}

					     	if ((rdata[1] == 0xF0) && (rdata[2] == 0x9E) )
							{
									 //Pos Resp

											tx_head.DLC=6;
											tx_head.IDE=CAN_ID_STD;
											tx_head.StdId=0x140;
											tx_head.RTR=CAN_RTR_DATA;

											tdata[0]= 0x64;
											tdata[1]= rdata[1];
											tdata[2]= rdata[2];
											tdata[3]= 0x60;
											tdata[4]= 0xFF;
											tdata[4]= 0x38;


											if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
											{
												Error_Handler();
											}

											while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

							}

					}

					else
					{
						//incorrectmsglength();
						tx_head.DLC=3;
								tx_head.IDE=CAN_ID_STD;
								tx_head.StdId=0x120;
								tx_head.RTR=CAN_RTR_DATA;

								tdata[0]= 0x7F;
								tdata[1]= 0x24;
								tdata[2]= 0x13;

								if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
								{
									Error_Handler();
								}

								while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
					}

			}
	else if ( rdata[0]==0x10) // Session control service
			{
			if (  rx_head.DLC == 2)
					{
						if ((rdata[1] > 0x03) || (rdata[1] == 0x00) )
							{

							         /*Sub function not supported */

										tx_head.DLC=3;
										tx_head.IDE=CAN_ID_STD;
										tx_head.StdId=0x140;
										tx_head.RTR=CAN_RTR_DATA;

										tdata[0]= 0x7F;
										tdata[1]= 0x10;
										tdata[2]= 0x12;

										if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
										{
											Error_Handler();
										}

										while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

							}


						if (rdata[1] == 0x01 )
						   {
							/* Default session */

							udsCurSession_u8 = UDS_DEFAULT_SESSION;

								tx_head.DLC=6;
								tx_head.IDE=CAN_ID_STD;
								tx_head.StdId=0x200;
								tx_head.RTR=CAN_RTR_DATA;

								tdata[0]= 0x50;
								tdata[1]= 0x01;
								tdata[2]= 0x00;
								tdata[3]= 0x32;
								tdata[4]= 0x13;
								tdata[5]= 0x88;
						   }
						if (rdata[1] == 0x02 )
						   {
							/* Programming session */

							udsCurSession_u8 = UDS_PRGRAMMING_SESSION;

							  if (s3_server_active_flg==1U)
							    {
								    u32_S3_server_cnt++;
									/* S3 server time out handling */
									if(u32_S3_server_cnt == S3_CNT_TIMEOUT)
									   {
									    /* When the extended session timeout happens, it will reset to default session. */
									      udsCurSession_u8=UDS_DEFAULT_SESSION;
									   }
							    }
							  else
							   {
								     /* Reset the S3 server timer count. */
								     u32_S3_server_cnt=0;
							   }

								tx_head.DLC=6;
								tx_head.IDE=CAN_ID_STD;
								tx_head.StdId=0x200;
								tx_head.RTR=CAN_RTR_DATA;

							    tdata[0]= 0x50;
								tdata[1]= 0x02;
							    tdata[2]= 0x00;
								tdata[3]= 0x32;
								tdata[4]= 0x13;
								tdata[5]= 0x88;
		  				   }
						if (rdata[1] == 0x03 )
						   {
							  /* Extended session */
							udsCurSession_u8 = UDS_EXTENDED_SESSION;

							  if (s3_server_active_flg==1U)
							    {
							      u32_S3_server_cnt++;
							      /* S3 server time out handling */
							      if(u32_S3_server_cnt == S3_CNT_TIMEOUT)
							      {
							        /* When the extended session timeout happens, it will reset to default session. */
							        udsCurSession_u8=UDS_DEFAULT_SESSION;
							      }
							    }
							    else
							    {
							      /* Reset the S3 server timer count. */
							      u32_S3_server_cnt=0;
							    }

							    /* Reset S3 server timer when default session is active. */
							    if(udsCurSession_u8==UDS_DEFAULT_SESSION)
							    {
							      s3_server_active_flg=0;

							    }
							    tx_head.DLC=6;
								tx_head.IDE=CAN_ID_STD;
								tx_head.StdId=0x200;
								tx_head.RTR=CAN_RTR_DATA;

								tdata[0]= 0x50;
								tdata[1]= 0x03;
								tdata[2]= 0x00;
								tdata[3]= 0x32;
								tdata[4]= 0x13;
								tdata[5]= 0x88;
						   }



								if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
								{
									Error_Handler();
								}

								while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

						}

					else
					{
						     /*  incorrectmsglength */
						        tx_head.DLC=3;
								tx_head.IDE=CAN_ID_STD;
								tx_head.StdId=0x120;
								tx_head.RTR=CAN_RTR_DATA;

								tdata[0]= 0x7F;
								tdata[1]= 0x10;
								tdata[2]= 0x13;

								if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
								{
									Error_Handler();
								}

								while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
					}

			}

	else if ( rdata[0]==0x11) // Reset Service
		{
		if (  rx_head.DLC == 2)
				{
					if (rdata[1] > 0x02 )
						{
						           /*Sub function not supported */

									tx_head.DLC=3;
									tx_head.IDE=CAN_ID_STD;
									tx_head.StdId=0x140;
									tx_head.RTR=CAN_RTR_DATA;

									tdata[0]= 0x7F;
									tdata[1]= 0x11;
									tdata[2]= 0x12;

									if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
									{
										Error_Handler();
									}

									while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

						}

					//if ( (rdata[1]==0xff)  &&  (rdata[2]==0x1) )
					if (rdata[1] == 0x01 )
					   {

                            /* Hard Reset */

							tx_head.DLC=3;
							tx_head.IDE=CAN_ID_STD;
							tx_head.StdId=0x200;
							tx_head.RTR=CAN_RTR_DATA;

							tdata[0]= 0x51;
							tdata[1]= 0x11;
							tdata[2]= 0x44;



							if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
							{
								Error_Handler();
							}

							while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

							NVIC_SystemReset();

					   }

					//if ( (rdata[1]==0xFF)  &&  (rdata[2]==0x2) )
					if (rdata[1] == 0x02 )
						  {
								/* KeyOffOnReset */

						        tx_head.DLC=3;
								tx_head.IDE=CAN_ID_STD;
								tx_head.StdId=0x200;
								tx_head.RTR=CAN_RTR_DATA;

								tdata[0]= 0x51;
								tdata[1]= 0x11;
   							    tdata[2]= 0x44;


							if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
							{
								Error_Handler();
							}

							while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

						  }

				}

				else
				{
					/*incorrect msg length */

					        tx_head.DLC=3;
							tx_head.IDE=CAN_ID_STD;
							tx_head.StdId=0x120;
							tx_head.RTR=CAN_RTR_DATA;

							tdata[0]= 0x7F;
							tdata[1]= 0x11;
							tdata[2]= 0x13;

							if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
							{
								Error_Handler();
							}

							while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
				}

		}
	else if ( rdata[0]==0x27)
		{
		if (  rx_head.DLC == 2 || rx_head.DLC == 4 )
				{
					if (rdata[1] > 0x02 )
						{
						           /*Sub function not supported */

									tx_head.DLC=3;
									tx_head.IDE=CAN_ID_STD;
									tx_head.StdId=0x140;
									tx_head.RTR=CAN_RTR_DATA;

									tdata[0]= 0x7F;
									tdata[1]= 0x27;
									tdata[2]= 0x12;

									if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
									{
										Error_Handler();
									}

									while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

						}

					//if ( (rdata[1]==0xff)  &&  (rdata[2]==0x1) )
					if (rdata[1] == 0x01 )
					   {

                            /* Response for Seed Request  */

						    seq_cnt=0x01;// Sequence check : Seed sent before Key verification

							tx_head.DLC=4;
							tx_head.IDE=CAN_ID_STD;
							tx_head.StdId=0x200;
							tx_head.RTR=CAN_RTR_DATA;

							tdata[0]= 0x67;
							tdata[1]= 0x01;
							/* 2 byte Seed Value */
							tdata[2]= 0x02;
							tdata[3]= 0x03;



							if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
							{
								Error_Handler();
							}

							while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;


					   }
					else if (rdata[1] == 0x02 )
						{

					           /* Key Validation  */

						 if(rdata[2] == 0x04 && rdata[3] == 0x05)
						 	 {
							  if(seq_cnt == 0x01) // Sequence check : Key verification After sending seed
							  	  {
								    /* Reseting sequence counter */
								       seq_cnt = 0x00;

								    /* Unlocking the ECU */

								  	  securityAccessState_en = SECURITY_UNLOCK;

							      /* Sending Positive response */

								  	  tx_head.DLC=2;
								  	  tx_head.IDE=CAN_ID_STD;
								  	  tx_head.StdId=0x200;
								  	  tx_head.RTR=CAN_RTR_DATA;

								  	  tdata[0]= 0x67;
								  	  tdata[1]= 0x02;


								  	  if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
								  	  	  {
								  		  	  Error_Handler();
								  	  	  }

								  	  while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
							  }
							  else
							  {
								  /* Requence Sequence Error */

								     tx_head.DLC=3;
								  	 tx_head.IDE=CAN_ID_STD;
								  	 tx_head.StdId=0x120;
								  	 tx_head.RTR=CAN_RTR_DATA;

								  	 tdata[0]= 0x7F;
								  	 tdata[1]= 0x27;
								  	 tdata[2]= 0x24;

								  	 if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
								  	 	 {
								  		 	 Error_Handler();
								  		 }

     							 	while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
							  }

							  }
						 else
						 {
							 /*Invalid Key */

							 	tx_head.DLC=3;
							 	tx_head.IDE=CAN_ID_STD;
							 	tx_head.StdId=0x120;
							 	tx_head.RTR=CAN_RTR_DATA;

							 	tdata[0]= 0x7F;
							 	tdata[1]= 0x27;
							 	tdata[2]= 0x35;

							 	if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
							 		{
							 			Error_Handler();
							 		}

							 	while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
						 }
				    }

				}

				else
				{
					/*incorrect msglength */

					        tx_head.DLC=3;
							tx_head.IDE=CAN_ID_STD;
							tx_head.StdId=0x120;
							tx_head.RTR=CAN_RTR_DATA;

							tdata[0]= 0x7F;
							tdata[1]= 0x27;
							tdata[2]= 0x13;

							if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
							{
								Error_Handler();
							}

							while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
				}

		}
	else if ( rdata[0]==0x28) //Communication control
	{
		if (  rx_head.DLC == 5)
			{
				if (rdata[1] > 0x03 )
					{
					  /*Sub function not supported */
											tx_head.DLC=3;
											tx_head.IDE=CAN_ID_STD;
											tx_head.StdId=0x140;
											tx_head.RTR=CAN_RTR_DATA;

											tdata[0]= 0x7F;
											tdata[1]= 0x28;
											tdata[2]= 0x12;

											if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
											{
												Error_Handler();
											}

											while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

					}
					else
					{
					if(( rdata[2] >= 0x01  )&&( rdata[2] <= 0x03) )
						{

		                            /* 00 -Enable rx&tx ;01 -Enable rx& disable tx;
		                             * 02 -disable rx& enable tx;03 -disable rx&tx */

									tx_head.DLC=2;
									tx_head.IDE=CAN_ID_STD;
									tx_head.StdId=0x200;
									tx_head.RTR=CAN_RTR_DATA;

									tdata[0]= 0x68;
									tdata[1]= rdata[1];



									if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
									{
										Error_Handler();
									}

									while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

									NVIC_SystemReset();

						}
					else
					 	 {
									 /*Request out of Range */
											tx_head.DLC=3;
											tx_head.IDE=CAN_ID_STD;
											tx_head.StdId=0x140;
											tx_head.RTR=CAN_RTR_DATA;
											tdata[0]= 0x7F;
											tdata[1]= 0x28;
											tdata[2]= 0x31;
											if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
											{
												Error_Handler();
											}
											while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
					 	 }
					}
	}
	else
	{

		/*incorrect msg length */

									        tx_head.DLC=3;
											tx_head.IDE=CAN_ID_STD;
											tx_head.StdId=0x120;
											tx_head.RTR=CAN_RTR_DATA;

											tdata[0]= 0x7F;
											tdata[1]= 0x28;
											tdata[2]= 0x13;

											if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
											{
												Error_Handler();
											}

											while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;/*Service not supported */
	}

   }
   else if ( rdata[0]==0x85) // Control DTC setting
			{
			if (  rx_head.DLC == 2)
					{
						if (rdata[1] > 0x02 )
							{
							           /*Sub function not supported */

										tx_head.DLC=3;
										tx_head.IDE=CAN_ID_STD;
										tx_head.StdId=0x140;
										tx_head.RTR=CAN_RTR_DATA;

										tdata[0]= 0x7F;
										tdata[1]= 0x11;
										tdata[2]= 0x12;

										if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
										{
											Error_Handler();
										}

										while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

							}

						//if ( (rdata[1]==0xff)  &&  (rdata[2]==0x1) )
						if (rdata[1] == 0x01 )
						   {

	                            /* Start updating DTC setting  */

								tx_head.DLC=2;
								tx_head.IDE=CAN_ID_STD;
								tx_head.StdId=0x200;
								tx_head.RTR=CAN_RTR_DATA;

								tdata[0]= 0xC5;
								tdata[1]= 0x01;



								if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
								{
									Error_Handler();
								}

								while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

								NVIC_SystemReset();

						   }

						if (rdata[1] == 0x02 )
							  {
							      /* Start updating DTC setting  */

							        tx_head.DLC=2;
									tx_head.IDE=CAN_ID_STD;
									tx_head.StdId=0x200;
									tx_head.RTR=CAN_RTR_DATA;

									tdata[0]= 0xC5;
									tdata[1]= 0x02;

								if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
								{
									Error_Handler();
								}

								while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;

							  }

					}

					else
					{
						/*incorrect msg length */

						        tx_head.DLC=3;
								tx_head.IDE=CAN_ID_STD;
								tx_head.StdId=0x120;
								tx_head.RTR=CAN_RTR_DATA;

								tdata[0]= 0x7F;
								tdata[1]= 0x85;
								tdata[2]= 0x13;

								if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
								{
									Error_Handler();
								}

								while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
					}

			}
   else
   {
	   /*Service not supported */

	   						        tx_head.DLC=3;
	   								tx_head.IDE=CAN_ID_STD;
	   								tx_head.StdId=0x120;
	   								tx_head.RTR=CAN_RTR_DATA;

	   								tdata[0]= 0x7F;
	   								tdata[1]= rdata[0];
	   								tdata[2]= 0x11;

	   								if(HAL_CAN_AddTxMessage(&hcan, &tx_head,tdata, &txmailbox)!=HAL_OK)
	   								{
	   									Error_Handler();
	   								}

	   								while ( HAL_CAN_IsTxMessagePending( &hcan,  txmailbox )  ) ;
   }

}

void udsreadcall(void)
{


}






void Error_Handler(void)
{

  __disable_irq();
  while (1)
  {
  }

}

#ifdef  USE_FULL_ASSERT


void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
